DELETE FROM dtb_blocposition WHERE page_id <> 0 AND device_type_id = 10;

INSERT INTO dtb_blocposition VALUES (10, 1, 4, 12, 1, 0);
INSERT INTO dtb_blocposition VALUES (10, 1, 4, 5, 3, 0);
INSERT INTO dtb_blocposition VALUES (10, 1, 4, 11, 2, 0);
INSERT INTO dtb_blocposition VALUES (10, 1, 5, 7, 2, 0);
INSERT INTO dtb_blocposition VALUES (10, 1, 1, 6, 1, 1);
INSERT INTO dtb_blocposition VALUES (10, 1, 1, 3, 2, 1);
INSERT INTO dtb_blocposition VALUES (10, 1, 1, 1, 3, 1);
INSERT INTO dtb_blocposition VALUES (10, 1, 1, 8, 4, 1);
INSERT INTO dtb_blocposition VALUES (10, 1, 1, 2, 5, 1);
INSERT INTO dtb_blocposition VALUES (10, 1, 5, 4, 1, 1);
INSERT INTO dtb_blocposition VALUES (10, 29, 4, 10, 1, 0);
