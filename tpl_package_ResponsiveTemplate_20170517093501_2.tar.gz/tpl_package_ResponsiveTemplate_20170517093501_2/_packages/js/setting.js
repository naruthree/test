/*
 * requires:jQuery v1.10.1 later
 * name:settings.js
 * author:Manabu Kushimoto(web-park.org)
 */

var GN={
	ww:function(){ var v=$(window).innerWidth(); return v; },
	wh:function(){ var v=$(window).innerHeight(); return v; },
	dh:function(){
		var v=Math.max.apply(null,[document.body.clientHeight,document.body.scrollHeight,document.documentElement.scrollHeight,document.documentElement.clientHeight]);
		return v;
	},
	wrap:function(){ var v=$(".wrap").innerWidth(); return v; },
	st:function(){ var v=$(window).scrollTop(); return v; },
	ua:navigator.userAgent
}

jQuery(function($){

	$.fn.extend({
		// ページ内スクロール
		pageScroll:function(options){
			var defaults={
				speed:800
			};
			var op=$.extend(defaults,options);
			var $t=$(this);
			$t.on("click",function(){
				var Hash=$(this.hash);
				try{
					var HashOffset=$(Hash).offset().top;
				}catch(e){
					return false;
				}
				$("html:not(:animated),body:not(:animated)").animate({
					scrollTop: HashOffset
				},op.speed);
				return false;
			});
		},
		// レスポンシブル
		responsible:function(options){
			var defaults={
				w:{
					tablet:1000,
					sp:700
				},
				products:$("#products_list .item_list > li,#related_item .item_list > li")
			};
			var op=$.extend(defaults,options);
			var $t=$(this);
			// 商品一覧画像を正方形に保つ
			var productsList=function(){
				op.products.each(function(){
					var $photo=$(this).find(".photo");
					var w={
						photo:$photo.width(),
						img:$photo.find("img").width()
					}
					var h={
						photo:$photo.height(),
						img:$photo.find("img").height()
					}
					if(GN.ww()<op.w.tablet){
						$photo.height(w.photo);
						if(w.photo/w.img>w.photo/h.img){
							$photo.find("img").width("auto").height(w.photo);
						}else{
							$photo.find("img").width("100%").height("auto");
						}
					}else{
						$photo.find("img").width("auto").height("auto");
					}
				});
			}

			$t.on({
				"load":function(){
					productsList();
				},
				"resize":function(){
					productsList();
				}
			});

		},
		// サイトメニュー
		siteMenu:function(options){
			var defaults={
				speed:300
			};
			var op=$.extend(defaults,options);
			var $t=$(this);
			var $id=$($t.attr("href"));
			var h=0;

			$t.on("click",function(){
				$id.show().css({ opacity:0 });
				h=$id.height();
				$id.css({ top:-h+"px" }).animate({
					top:0,
					opacity:1
				},op.speed);
			});

			$id.find(".btn_close a").on("click",function(){
				$id.animate({
					top:-h+"px",
					opacity:0
				},op.speed);
			});

		},
		// スライド
		slide:function(options){
			var defaults={
				limit:4,
				speed:300,
				interval:0
			};
			var op=$.extend(defaults,options);
			var $t=$(this);
			var $frame=$t.find(".frame");
			var $move=$t.find(".move");
			var $li=$move.find("li");
			var direct={
				prev:$('<a class="prev" href="#" />'),
				next:$('<a class="next" href="#" />')
			}
			var w=0;
			var len=$li.length;
			var index=0;
			var left=len*w;
			var next_index=0;
			var autoEvent="";
			var autoInterval=""
			var bool=true;
			// 矢印表示非表示
			var arrowDisplay=function(){
				if(index==0){
					direct.prev.hide();
					direct.next.show();
				}else if(index==Math.floor((len-1)/op.limit)){
					direct.prev.show();
					direct.next.hide();
				}else{
					direct.prev.show();
					direct.next.show();
				}
			}
			// スライドイベント
			var slideEvent=function(){
				$move.stop(true,false).animate({
					left:-w*index+"px"
				},op.speed,function(){
					bool=true;
					arrowDisplay();
				});
			};
			// 自動切り替え
			autoEvent=function(){
				if(op.interval){
					autoInterval=setTimeout(function(){
						index=(index==len-op.limit)?0:index+1;
						slideEvent();
						autoEvent();
					},op.interval);
				}
			};
			// 初期設定
			var firstSet=function(){
				$move.width(w*len).css({ left:-(w*index)+"px" });
				$li.width(w/op.limit);
				var h_arr=new Array();
				var h=0;
				for(var i=0;i<len;i++){
					var t=$li.eq(i).innerHeight();
					h_arr.push(t);
				}
				var h_max=Math.max.apply(null,h_arr);
				$frame.height(h_max);
			}

			$(window).on({
				"load":function(){
					w=$frame.width();
					if(op.limit<=len){
						firstSet();
						arrowDisplay();
						$t.append(direct.prev,direct.next);
						autoEvent();
					}
				},
				"resize":function(){
					w=$frame.width();
					if(op.limit<=len) firstSet();
				}
			});

			// 前へクリック
			direct.prev.click(function(){
				if(bool){
					bool=false;
					index=index-1;
					clearTimeout(autoInterval);
					slideEvent();
					autoEvent();
				}
				return false;
			});

			// 次へクリック
			direct.next.click(function(){
				if(bool){
					bool=false;
					index=index+1;
					clearTimeout(autoInterval);
					slideEvent();
					autoEvent();
				}
				return false;
			});
		},
		// タブスライド切り替え
		tabSlide:function(options){
			var defaults={
				speed:300
			};
			var op=$.extend(defaults,options);
			var $t=$(this);
			var $frame=$t.find(".frame");
			var $move=$t.find(".move");
			var $ol=$move.find("ol");
			var $nav=$(this).find(".nav");
			var $li=$nav.find("li");
			var w=0;
			var len=$ol.length;
			var index=0;
			// タブイベント
			var tabEvent=function(){
				$li.find("a.on").removeClass("on");
				$li.eq(index).find("a").addClass("on");
				$move.animate({
					left:-(w*index)+"px"
				},op.speed);
			}
			// 初期設定
			var firstSet=function(){
				$move.width(w*len).css({ left:-(w*index)+"px" });
				$ol.width(w);
				var h_arr=new Array();
				var h=0;
				for(var i=0;i<$ol.find("li").length;i++){
					var t=$ol.find("li").eq(i).innerHeight();
					h_arr.push(t);
				}
				var h_max=Math.max.apply(null,h_arr);
				$frame.height(h_max);
			}


			$(window).on({
				"load":function(){
					w=$frame.width();
					firstSet();
				},
				"resize":function(){
					w=$frame.width();
					firstSet();
				}
			});

			// クリックイベント
			$li.find("a").off("click");
			$li.on("click","a",function(){
				var $id=$($(this).attr("href"));
				index=$move.find("ol").index($id);
				tabEvent();
				return false;
			});

		}
	});

	$("a[href^=#]").pageScroll({speed:600});
	$(window).responsible();
	$("a[href^=#site_menu]").siteMenu();
	if($("#new_item .slide_block").length) $("#new_item .slide_block").slide({ limit:4 });
	if($("#shop_ranking").length) $("#shop_ranking").tabSlide();

});